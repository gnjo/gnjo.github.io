"Mouse Emulator"
This program is freeware. If you really like this program, and want to make a donation, 
please go to the website for more information. Thank you.

The program runs under windows NT/9x and above.
The homepage of this utility is http://www.geocities.com/matroxfiles
--------------------------------------------------------------------------

Copyright (c) 2002 RH Designs (RHD)

This file contains the following information:
1. License Agreement
2. Manual



1.        License Agreement

USE OF THIS SOFTWARE IS SUBJECT TO THE SOFTWARE LICENSE TERMS SET FORTH
BELOW. USING THE SOFTWARE INDICATES YOUR ACCEPTANCE OF THESE TERMS. IF
YOU DO NOT ACCEPT THESE TERMS, YOU MUST DELETE THE SOFTWARE IMMEDIATELY.
"Use" means storing, loading, installing, executing or displaying the
software. You may not modify the software or disable any licensing or
control features of the software or revers engineer the software.

You may not copy or reproduce the software for any purpose
except to make one (1) archival copy of the software, or te redistribute the shareware
version including this readme.txt file. You may not give
copies of this software to other people. You may not sell, rent or lease
the software to others. 

You are entitled to use this product for
your own use. You may not sell, rent or lease the software to others
without written permission of the author (RHD). You may use only
one copy of the software at one time. You may not use this software on a
network or on more than one computer at the same time without a license for
"concurrent use". 

You must not give away your personal copy. Doing so will result in an
infringement of copyright. RHD retains the right of claims for
compensation in respect of damage which occurred by your giving away of the
software copy. This claim shall also extent to all costs which RHD
incurs in defending himself.

THE SOFTWARE IS WARRANTED IF AT ALL ONLY ACCORDING TO THE TERMS OF THIS
LICENSING AGREEMENT. EXCEPT AS WARRANTED HEREIN, RHD HEREBY DISCLAIMS ALL
WARRANTIES AND CONDITIONS WITH REGARD TO THE SOFTWARE, INCLUDING ALL IMPLIED
WARRANTIES AND CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
PURPOSE, TITLE AND NON-INFRINGEMENT.

2. Manual
Thank you for using this utility.

The program recognizes the following keys: (NumLock must be ON!)
Keypad 1 - Left mouse button
Keypad 2 - Right mouse button
Keypad 3 - Middle mouse button
Keypad 4, 5, 6, 8 - Moves the mouse left, down, right or up respectively. 
Keypad 7 - Mousewheel up (Scroll)
Keypad 9 - Mousewheel down (Scroll)
Keypad / - Toggle Left mouse button (Useful for RSI users)
Keypad * - Toggle Right mouse button (Useful for RSI users)
Keypad - - Toggle Middle mouse button (Useful for RSI users)

Ctrl + Keypad 0 - Enable/Disable Mouse emulator

You can exit Mouse Emulator by right clicking on the mouse icon in the taskbar.

Adjusting the mouse speed:
Double click on one of the .reg files and restart the program to change the
mouse speed. For instance double-click on SlowMouseSpeed.reg and restart the
program if you think the mouse speed of mouse emulator is too high.

For advanced users:
If you want to adjust the mouse speed, you can use regedit to change
the registry values.

Known Problems:
Mouse Emulator does not work with MS-Dos prompts (9x)
Mouse Emulator does not work with DirectX Mouse Input (DirectInput)
